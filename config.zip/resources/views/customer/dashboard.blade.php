@extends('customer.master')
@section('body')

    <div class="full-row px-40 py-30 xs-p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <h3 class="my-3">Welcome to Dashboard</h3>
                </div>
            </div>

        </div>
    </div>

@endsection
