<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="full-row py-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h3 class="text-secondary"><?php echo e($project->project_name); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="full-row pt-0">
        <div class="container">
            <div class="row row-cols-1 g-4">
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <!-- Property Grid -->
                    <div class="property-list-2 p-2 bg-white property-block border transation-this hover-shadow rounded">
                        <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                            <div class="cata position-absolute"><span class="sale bg-secondary text-white">For Sale</span></div>
                            <div class="owl-carousel single-carusel dot-disable nav-between-in">
                                <?php
                                    $images = explode (",", $row->images);

                                ?>
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('website.properties.show',$row->id)); ?>"><img src="<?php echo e(asset('uploads/propertyImages/'.$image)); ?>"  alt="Image Not Found!"></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <a href="#" class="listing-ctg text-white"><i class="fa-solid fa-building"></i><span>Apartment</span></a>

                        </div>
                        <div class="property_text p-3">
                            <h5 class="listing-title"><a href=""><?php echo e($row->property_name); ?></a></h5>
                            <span class="listing-location"><i class="fas fa-map-marker-alt"></i><?php echo e($row->location); ?> </span>
                            <ul class="d-flex quantity font-fifteen">
                                <li title="Beds"><span><i class="fa-solid fa-bed"></i></span><?php echo e($row->number_of_bedrooms); ?></li>
                                <li title="Baths"><span><i class="fa-solid fa-shower"></i></span><?php echo e($row->number_of_bathrooms); ?></li>
                                <li title="Area"><span><i class="fa-solid fa-vector-square"></i></span><?php echo e($row->size); ?> Sqft</li>
                            </ul>
                            <p><?php echo $row->short_description; ?></p>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="d-flex mt-5">
                <?php echo $properties->links(); ?>

            </div>
        </div>

    </div>



    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Home_Sweet\resources\views/website/property_listing.blade.php ENDPATH**/ ?>