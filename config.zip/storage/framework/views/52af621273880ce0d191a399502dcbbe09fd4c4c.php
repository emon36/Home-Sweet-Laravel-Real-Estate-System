<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-10 mx-auto mt-3">
            <div class="card mb-md-0">
                <div class="card-body">
                    <div class="card-title">Add Payment</div>
                    <form class="form-horizontal" action="<?php echo e(route('seller.transaction.store')); ?>"  method="POST">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                        <input type="hidden" name="user_id" value="<?php echo e($order->user_id); ?>">
                        <input type="hidden" name="property_id" value="<?php echo e($order->property_id); ?>">

                        <div class="row mb-3">
                            <label for="inputRole" class="col-3 col-form-label">Description</label>
                            <div class="col-9">
                                <input type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" />
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                               </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="inputRole" class="col-3 col-form-label">Pay Amount</label>
                            <div class="col-9">
                                <input type="number"  class="form-control <?php $__errorArgs = ['pay_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pay_amount"  />
                                <?php $__errorArgs = ['pay_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                               </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="inputRole" class="col-3 col-form-label">Payment Date</label>
                            <div class="col-4">
                                <input type="date" id="example-date"  class="form-control <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="payment_date" />
                                <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                               </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="justify-content-end row">
                            <div class="col-9">
                                <button type="submit" class="btn btn-info">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script>



        $(document).ready(function(){
            $('select[name="project"]').on('change',function(){
                var project_id = $(this).val();
                if (project_id) {

                    $.ajax({
                        url: "<?php echo e(url('admin/order/get/property/')); ?>/"+project_id,
                        type:"GET",
                        dataType:"json",
                        success:function(data) {
                            var d = $('select[name="property"]').empty();
                            $.each(data, function(key, value){

                                $('select[name="property"]').append('<option value="">' +'Select Property '+ '</option>');

                                $('select[name="property"]').append('<option value="'+ value.id + '">' + value.property_name + '</option>');
                            });
                        },
                    });
                }else{
                    alert('danger');
                }
            })




        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yeasin_city\resources\views/seller/transaction/create.blade.php ENDPATH**/ ?>