<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="full-row bg-light">
        <div class="container">
            <div class="col">
                <h3>Our Gallery</h3>
            </div>
            <div class="row mt-5 ">
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-8 col-md-6 col-lg-4 mb-3">
                        <div class="card h-100">
                            <img class="card-img" src="<?php echo e(asset('uploads/galleryImages/'.$row->image)); ?>" height="250" alt="news image">

                            <div class="card-body">

                                <p class="card-text"><?php echo e($row->caption); ?></p>

                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="d-flex">
                <?php echo $gallery->links(); ?>

            </div>

        </div>

    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yeasin_city\resources\views/website/gallery.blade.php ENDPATH**/ ?>