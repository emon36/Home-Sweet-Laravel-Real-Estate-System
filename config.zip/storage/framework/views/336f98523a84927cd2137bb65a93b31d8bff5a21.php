<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12 mx-auto mt-3">
            <div class="card mb-md-0">
                <div class="card-body">
                    <div class="card-title">Employees</div>

                    <div class="table-responsive">
                        <table class="table text-center table-centered table-borderless table-hover w-100 dt-responsive nowrap" id="seller-datatable">
                            <thead class="table-light">
                            <tr>
                                <th>Employee ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Salary</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->employee_id); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->phone); ?></td>
                                    <td><?php echo e($row->salary); ?></td>
                                    <td><img src="<?php echo e(asset('uploads/employeeImages/'.$row->image)); ?>" height="100"/> </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.employee.edit',$row->id)); ?>" data-original-title="edit" class="edit btn btn-info btn-sm"> <i class="mdi mdi-square-edit-outline"></i></a>
                                        <a href="javascript:void(0)"   data-id="<?php echo e($row->id); ?>" data-original-title="delete" class="edit btn btn-danger btn-sm deleteEmployee"> <i class="mdi mdi-delete"></i></a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

        $(document).ready( function () {
            var table = $('#seller-datatable').DataTable({
                'columnDefs': [ {
                    'targets': [4,5],
                    'orderable': false,

                }]
            });

            $('body').on('click', '.deleteEmployee', function () {

                var id = $(this).data("id");
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: '/admin/delete/employee/'+id,
                            method: 'delete',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>'
                            },
                            success: function(response) {
                                console.log(response);
                                Swal.fire(
                                    'Deleted!',
                                    'Employee has been deleted.',
                                    'success'
                                )
                                setTimeout(() => {
                                    location.reload();
                                }, 2000)

                            }
                        });
                    }
                });

            });


        } );


    </script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yeasin_city\resources\views/admin/employee/index.blade.php ENDPATH**/ ?>