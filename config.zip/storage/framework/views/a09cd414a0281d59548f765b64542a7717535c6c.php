<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="full-row bg-light">
        <div class="container">
            <div class="row">
                <div class="col mb-4">
                    <div class="align-items-center d-flex">
                        <div class="me-auto">
                            <h2 class="d-table">Our Projects</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="3block-carusel nav-disable owl-carousel">
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <!-- Property Grid -->
                                <?php
                                    $images = explode (",", $project->images);
                                    $image = $images[0];
                                ?>
                                <div class="property-grid-1 property-block bg-white transation-this">
                                    <div class="overflow-hidden position-relative transation thumbnail-img bg-secondary hover-img-zoom">
                                        <a href="<?php echo e(route('website.project.show',$project->id)); ?>"><img src="<?php echo e(asset('uploads/projectImages/'.$image)); ?>" height="250" width="100%" alt="Image Not Found!"></a>
                                        <p class="listing-ctg text-white"><i class="fa-solid fa-building"></i><span>Project</span></p>
                                    </div>
                                    <div class="property_text p-4">
                                        <h5 class="listing-title"><a href="<?php echo e(route('website.project.show',$project->id)); ?>"><?php echo e($project->project_name); ?> </a></h5>
                                        <span class="listing-location"><i class="fas fa-map-marker-alt"></i><?php echo e($project->location); ?> </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yeasin_city\resources\views/website/projects.blade.php ENDPATH**/ ?>