<header class="header-style nav-on-top bg-white ">
    <div class="main-nav">
        <div class="container">
            <div class="row">
                <div class="col">
                    <nav class="navbar navbar-expand-lg nav-secondary navbar-light nav-primary-hover nav-line-active">
                        <a class="navbar-brand" href="<?php echo e(route('website.home')); ?>"><img class="nav-logo" src="<?php echo e(asset('frontend/images/logo/sweet-home-logo.jpg')); ?>" alt="Image not found !"></a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class=" flaticon-menu flat-small text-primary"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('website.home')); ?>">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('website.service')); ?>">Service</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('website.projects')); ?>">Projects</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('website.gallery')); ?>">Gallery</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('website.contact')); ?>">Contact</a>
                                </li>

                                <?php if(auth()->guard()->guest()): ?>

                                    <?php if(Route::has('login')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if(Route::has('register')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                        </li>
                                    <?php endif; ?>
                                  <?php else: ?>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link  dropdown-toggle" href="#"> <?php echo e(Auth::user()->name); ?></a>
                                        <ul class="dropdown-menu">
                                            <?php if(Auth::user()->role_id == 2): ?>
                                              <li><a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
                                            <?php elseif(Auth::user()->role_id == 1): ?>
                                               <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                            <?php else: ?>
                                              <li> <a class="dropdown-item" href="<?php echo e(route('seller.dashboard')); ?>">Dashboard</a></li>
                                            <?php endif; ?>
                                               <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                    <?php echo e(__('Logout')); ?>

                                                </a>
                                               </li>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                        </ul>
                                    </li>
                                <?php endif; ?>

                            </ul>

                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\xampp\htdocs\yeasin_city\resources\views/website/layouts/header.blade.php ENDPATH**/ ?>