<?php $__env->startSection('body'); ?>

    <div class="full-row px-40 py-30 xs-p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <h3 class="my-3">My Transactions</h3>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="dashboard-panel border bg-white rounded overflow-hidden w-100">
                        <div class="overflow-x-scroll font-fifteen">
                            <table class="w-100 items-list bg-transparent">
                                <thead>
                                <tr class="bg-white">
                                    <th>Transaction ID</th>
                                    <th >Property Name</th>
                                    <th>Paid Amount</th>
                                    <th>Payment Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row->transaction_code); ?></td>
                                        <td><?php echo e($row->properties->property_name); ?></td>
                                        <td><?php echo e($row->pay_amount); ?></td>
                                        <td><?php echo e($row->payment_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yeasin_city\resources\views/customer/transaction.blade.php ENDPATH**/ ?>